package pojo;

public class GetCourse 
{
	private String url;
	private String services;
	private String experties;
	private Courses courses;
	private String instuctor;
	private String linkedIn;

	public String getUrl() 
	{
		return url;
	}
	public void setUrl(String url) 
	{
		this.url = url;
	}
	public String getServices() 
	{
		return services;
	}
	public void setServices(String services) 
	{
		this.services = services;
	}
	public String getExperties() 
	{
		return experties;
	}
	public void setExperties(String experties) 
	{
		this.experties = experties;
	}
	public pojo.Courses getCourses() 
	{
		return courses;
	}
	public void setCourses(pojo.Courses courses) 
	{
		this.courses = courses;
	}
	public String getInstuctor() 
	{
		return instuctor;
	}
	public void setInstuctor(String instuctor) 
	{
		this.instuctor = instuctor;
	}
	public String getLinkedIn() 
	{
		return linkedIn;
	}
	public void setLinkedIn(String linkedIn) 
	{
		this.linkedIn = linkedIn;
	}


}
